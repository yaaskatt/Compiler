package mirea.interpreter;

public interface ElementInterface {
    String getType();
    String getValue();
}