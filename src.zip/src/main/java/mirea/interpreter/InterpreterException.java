package mirea.interpreter;

class InterpreterException extends Exception {
    InterpreterException(String message){
        super(message);
    }
}
